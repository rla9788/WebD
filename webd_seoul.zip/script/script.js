$(function(){
    let currentIndex = 0;
    $(".imageWrap").append($(".image").first().clone(true));

    setInterval(() => {
        currentIndex++;
        $(".imageWrap").animate({marginTop: -400 * currentIndex+"px"}, 600);

        if(currentIndex == 3){
            setTimeout(() => {
                $(".imageWrao").animate({marginTop: 0}, 0);
                currentIndex = 0;
            }, 600);
        }
    }, 3000);

    $(".nav>ul>li").mouseover(function(){
        $(this).find(".submenu").stop().slideDown();
    });
    $(".nav>ul>li").mouseout(function(){
        $(this).find(".submenu").stop().slideUp();
    });
});